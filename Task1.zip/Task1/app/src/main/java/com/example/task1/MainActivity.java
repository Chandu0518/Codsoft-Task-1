package com.example.task1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private ImageButton toggleBtn;
    boolean hasCameraFlash= false;
    boolean flashOn=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toggleBtn=findViewById(R.id.toggleBtn);

        hasCameraFlash=getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);

        toggleBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (hasCameraFlash){
                    if (flashOn){
                        flashOn=false;
                        toggleBtn.setImageResource(R.drawable.flashof);
                        try {
                            flashlightoff();
                        } catch (CameraAccessException e) {
                            throw new RuntimeException(e);
                        }
                    }
                    else {
                        flashOn=true;
                        toggleBtn.setImageResource(R.drawable.flashonn);
                        try {
                            flashlighton();
                        } catch (CameraAccessException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
                else {
                    Toast.makeText(MainActivity.this, "No Flash Available On Your Device", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private void flashlighton() throws CameraAccessException {
        CameraManager cameraManager=(CameraManager) getSystemService(Context.CAMERA_SERVICE);
        String cameraid=cameraManager.getCameraIdList()[0];
        cameraManager.setTorchMode(cameraid, Boolean.parseBoolean("true"));
        Toast.makeText(MainActivity.this, "Flash Light Is ON", Toast.LENGTH_SHORT).show();
    }
    private void flashlightoff() throws CameraAccessException {
        CameraManager cameraManager=(CameraManager) getSystemService(Context.CAMERA_SERVICE);
        String cameraid=cameraManager.getCameraIdList()[0];
        cameraManager.setTorchMode(cameraid, Boolean.parseBoolean("flase"));
        Toast.makeText(MainActivity.this, "Flash Light Is OFF", Toast.LENGTH_SHORT).show();
    }
}